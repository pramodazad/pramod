'use strict';

/**
 * @ngdoc function
 * @name planistoApp.controller:ResultsCtrl
 * @description
 * # ResultsCtrl
 * Controller of the planistoApp
 */
angular.module('planistoApp')
  .controller('ResultsCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
