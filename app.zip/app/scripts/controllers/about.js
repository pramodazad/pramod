'use strict';

/**
 * @ngdoc function
 * @name planistoApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the planistoApp
 */
 angular.module('planistoApp')
 .controller('AboutCtrl', function () {
  this.awesomeThings = [
  'HTML5 Boilerplate',
  'AngularJS',
  'Karma'
  ];
}).controller('UserPageCtrl', function ($scope, $timeout, $mdSidenav, $mdUtil, $log) {
  $scope.toggleLeft = buildToggler('left');
  $scope.toggleRight = buildToggler('right');

  $scope.signedIn = function(oauth) {
    $scope.user = oauth;
  }
    /**
     * Build handler to open/close a SideNav; when animation finishes
     * report completion in console
     */
     function buildToggler(navID) {
      var debounceFn =  $mdUtil.debounce(function(){
        $mdSidenav(navID)
        .toggle()
        .then(function () {
          $log.debug("toggle " + navID + " is done");
        });
      },200);
      return debounceFn;
    }
  }).controller('RightCtrl', function ($scope, $timeout, $mdSidenav, $log) {
    $scope.close = function () {
      $mdSidenav('right').close()
      .then(function () {
        $log.debug("close RIGHT is done");
      });
    };
  })
  
  .controller('RegisterEventCtrl', function ($scope) {


  })
  .controller('UserAfterLoginCtrl', function ($scope, UserInfo) {
    $scope.firstName= UserInfo.getFirstName();


  })
  .controller('pinCtrl', function ($scope) {
    $scope.value = [
      {title: "you have nothing", message: "add a new pin"}
      ];
      $scope.addPin = function (title,message){
        $scope.value.push({title: title, message: message});
      }

      
  })
  ;
