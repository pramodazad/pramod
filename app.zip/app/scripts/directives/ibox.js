'use strict';

angular.module('planistoApp')
 .controller('addbuttonCtrl', function ($scope) {
  $scope.count = 0;
})

.directive("addbuttonsbutton", function(){
	return {
		restrict: "E",
		template: "<button addbuttons>Click to add buttons</button>"
	}
})
.directive("addbuttons", function($compile){
	return function(scope, element, attrs){
		element.bind("click", function(){
			scope.count++;
			angular.element(document.getElementById('space-for-buttons'))
			.append($compile("<div><button class='btn btn-default' data-alert="+scope.count+" style='color: red;'>Show alert #"+scope.count+"</button></div>")
			(scope));
		});
	};
})
.directive("itemlist", function (){
	return {
		restrict: "A",
		replace: true,
		scope: {
			price: '@',
			productprice: '@'
		},
		template: "<div class='ibox'><div class='ibox-content product-box'><div class='product-imitation'>{{price}}</div><div class='product-desc'><span class='product-price'>{{productprice}}</span><small class='text-muted'>Category</small><a href='#' class='product-name'> Product</a><div class='small m-t-xs'>Many desktop publishing packages and web page editors now.</div><div class='m-t text-righ'><a href='#' class='btn btn-xs btn-outline btn-primary'>Info <i class='fa fa-long-arrow-right'></i> </a></div></div></div></div>"
	}
})
.directive("mydirective", function(){
	return{
		restrict: "A",
		replace: true,
		template: "<a href='http://www.google.com'>click</a>"
	}
})
;
/*//Directive for showing an alert on click
myApp.directive("alert", function(){
	return function(scope, element, attrs){
		element.bind("click", function(){
			console.log(attrs);
			
		});
	};
});*/